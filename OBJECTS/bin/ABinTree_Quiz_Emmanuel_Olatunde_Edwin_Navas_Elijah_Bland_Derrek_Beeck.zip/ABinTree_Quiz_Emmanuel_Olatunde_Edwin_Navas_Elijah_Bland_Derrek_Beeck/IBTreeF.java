package ABinTree_Quiz_Emmanuel_Olatunde_Edwin_Navas_Elijah_Bland_Derrek_Beeck;

public interface IBTreeF<X, Y> {
	
	public Y f(X v);
}
