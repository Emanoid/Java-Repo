package Interfaces;

public class zeronatnum implements Inatnum {
	public zeronatnum() {};
	public int getVal() {return(0);}
	
	public boolean isZero() {return true;}
	
	public boolean equal(Inatnum B) {return(B.isZero());}
	
	public Inatnum succ() {return(new nonzeronatnum(this));}
	
	public Inatnum pred() throws Exception{
		throw new Exception("Zero has no predecessor!");}
	
	public Inatnum add(Inatnum a) {return a;}
	
	public boolean lessthan(Inatnum a) {
		if(a.getVal()==0) {return false;}
		else {return true;}
	}
	public boolean greaterthan(Inatnum a) {return false;}
	
	public boolean leq(Inatnum a) {
		return true;}
	
	public boolean geq(Inatnum a) {
		if(a.getVal()!=0) {return false;}else {return true;}}
	
	public Inatnum subtract(Inatnum a) {
		//throw new Exception("Zero has no predecessor!");
		return a;
	} 
	public Inatnum multiply(Inatnum a) {return this;}
	
	public Inatnum quotient(Inatnum a) throws Exception{return this;}
	
	public Inatnum remainder(Inatnum a) throws Exception {return this;}
	
	public String ToString(){
		return "Natural Number: "+this.getVal()+"";	}
	
	public Inatnum print() {
		return this;}
	
	public static Inatnum factorial(){
		Inatnum zero = new zeronatnum();
		return zero.succ();
	}
}
