package Interfaces;

public class nonzeronatnum implements Inatnum{
	private int n; //the value of this natnum
	private Inatnum prev; //the natnum used to construct this natnum
	
	public nonzeronatnum(Inatnum natnum) {
		n = natnum.getVal() + 1;
		prev=natnum;
	}
	
	public int getVal() {return n;}
	
	public boolean isZero() {return false;}
	public boolean equal(Inatnum B) {return(this.n==B.getVal());}
	public Inatnum succ() {return(new nonzeronatnum(this));}
	public Inatnum pred() throws Exception {return prev;}
	
	public Inatnum add(Inatnum a) {
		try {return(this.pred().add(a).succ());}
		catch(Exception e) {System.out.println("Error add: "+ e.getMessage());
		return null;}
			}
	public boolean lessthan(Inatnum a) throws Exception{
		if((this.isZero() &&a.isZero())==true) {return false;}
		if((this.isZero())==false&&a.isZero()==true) {return false;}
		if((this.isZero())==true&&a.isZero()==false) {return true;}
		else {return this.pred().lessthan(a.pred());	}}
		
	public boolean greaterthan(Inatnum a) throws Exception{
		if((this.isZero() &&a.isZero())==true) {return false;}
		if((this.isZero())==false&&a.isZero()==true) {return true;}
		if((this.isZero())==true&&a.isZero()==false) {return false;}
		else {return this.pred().greaterthan(a.pred());	}
	}
		
	public boolean geq(Inatnum a) throws Exception {
		if((this.isZero() &&a.isZero())==true) {return true;}
		if((this.isZero())==false&&a.isZero()==true) {return true;}
		if((this.isZero())==true&&a.isZero()==false) {return false;}
		else {return this.pred().geq(a.pred());	}}
	
	public boolean leq(Inatnum a) throws Exception {
		if((this.isZero() &&a.isZero())==true) {return true;}
		if((this.isZero())==false&&a.isZero()==true) {return false;}
		if((this.isZero())==true&&a.isZero()==false) {return true;}
		else {return this.pred().leq(a.pred());	}}
	
	public Inatnum subtract(Inatnum a){
		try {return(this.pred().subtract(a).pred());}
		catch(Exception e) {System.out.println("Error add: "+ e.getMessage());
		return null;}
			}
		
		public Inatnum multiply(Inatnum a) {
			Inatnum zero = new zeronatnum(); 
			Inatnum res = zero;
			//INV: i>0 && i <= this.getval() && res = Sum[i]a ==> i=this.getval() 
			for(int i = this.getVal(); i>0;i--) {
			res = res.add(a);
				}return res;
				}
	
	public Inatnum quotient(Inatnum a) throws Exception{
		int N =n;
		if(a.isZero()==true) {return a;}
		Inatnum res = new zeronatnum();	
		while(N>=a.getVal()) {
			N=N-a.getVal();
			res = res.succ();
			}return res;
	}
	
	public Inatnum remainder(Inatnum a) throws Exception{
		int N = n;
		Inatnum res = new zeronatnum();	int remainder=0;
		while(N>=a.getVal()) {
			N=N-a.getVal();
			remainder = N;
			}int r=remainder;for(int i=1;i<=r;i++) {res=res.succ();} return res;
		}
	
	public String ToString(){
		return "Natural Number: "+this.n+" and Predecessor: "+this.prev.getVal();}
	
	public Inatnum print() {
		return this;}
	
	public static Inatnum factorial(int n) throws Exception{
		Inatnum res = new zeronatnum().succ();
		Inatnum dis = new zeronatnum(); for(int i=n;i>=1;i--) {dis=dis.succ();}
		Inatnum res1 = res; Inatnum dis1 = dis;
		while(dis1.getVal()>0) {
		res1 = res1.multiply(dis1); dis1=dis1.pred();
		}Inatnum newone = new zeronatnum();
		while(newone.getVal()!= res1.getVal()) {
			newone = newone.succ();
			}return newone;
	}
}
	