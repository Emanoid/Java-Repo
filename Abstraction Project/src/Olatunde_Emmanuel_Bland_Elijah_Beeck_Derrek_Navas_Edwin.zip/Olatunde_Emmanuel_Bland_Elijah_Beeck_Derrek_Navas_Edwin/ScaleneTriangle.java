package Olatunde_Emmanuel_Bland_Elijah_Beeck_Derrek_Navas_Edwin;
/**
 * Class for ScaleneTriangle
 * variable leftside => a
 * variable base => b
 * variable rightside =>c
 * variable height => h
 */
public class ScaleneTriangle extends Triangle{
	
	//Purpose: Implements an Scalene Triangle
	public ScaleneTriangle(double a, double b, double c, double h) throws Exception{
		super(a,b,c,h);	}
	}
