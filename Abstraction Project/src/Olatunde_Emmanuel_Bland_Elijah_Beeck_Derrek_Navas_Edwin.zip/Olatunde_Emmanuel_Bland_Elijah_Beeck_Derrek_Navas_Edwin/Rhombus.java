package Olatunde_Emmanuel_Bland_Elijah_Beeck_Derrek_Navas_Edwin;
/**
 * Class for Rhombus
 * variable length 
 * variable diagonal
 */
public class Rhombus extends Quadilateral{
	
	//Purpose: Implements a Rhombus
	public Rhombus(double length, double diagonal) throws Exception{
		super(length,diagonal);
			}

		
	}
