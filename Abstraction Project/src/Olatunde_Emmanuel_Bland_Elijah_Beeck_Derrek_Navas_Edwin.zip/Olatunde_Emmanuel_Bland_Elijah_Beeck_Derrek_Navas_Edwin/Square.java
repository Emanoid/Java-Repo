package Olatunde_Emmanuel_Bland_Elijah_Beeck_Derrek_Navas_Edwin;
/**
 * Class for Square
 * variable side => length of square
 */
public class Square extends Quadilateral {
	
	//Purpose: Implements a Square
	public Square(double side) throws Exception{
		super(side, side);		}
}
