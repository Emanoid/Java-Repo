package Olatunde_Emmanuel_Bland_Elijah_Beeck_Derrek_Navas_Edwin;
/**
 * Class for Rectangle
 * variable length => length of rectangle
 * variable width => width of rectangle
 */
public class Rectangle extends Quadilateral {
	
	//Purpose: Implements a Rectangle(lenght & Width)
	public Rectangle(double length, double width) throws Exception{
		super(length,width);	}	
}
