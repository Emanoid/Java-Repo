package Olatunde_Emmanuel_Bland_Elijah_Beeck_Derrek_Navas_Edwin;
/**
 * Class for EquilateralTriangle
 * variable base => a
 * variable height => h
 */
public class EquilateralTriangle extends Triangle{
	
		//Purpose: Implements an Equilateral Triangle
	public EquilateralTriangle(double a, double h) throws Exception{
		super(a,a,a,h);
		}
		
		}
